#!/usr/bin/env python3
"""Compare an exported ModelSim Data Memory dump with the single-run signatures."""

import argparse
import json
import re
from pathlib import Path


HEX_WORD = re.compile(r"^[0-9a-fA-F]{8}$")
ADDRESS = re.compile(r"^@([0-9a-fA-F]+)$")


def parse_dump(path, explicit_start):
    words = {}
    sequential = []
    cursor = None
    saw_address = False

    for raw_line in path.read_text().splitlines():
        line = raw_line.split("//", 1)[0].split("#", 1)[0].strip()
        if not line:
            continue
        for token in line.replace(",", " ").split():
            address_match = ADDRESS.match(token)
            if address_match:
                cursor = int(address_match.group(1), 16)
                saw_address = True
                continue
            token = token.removeprefix("0x").removeprefix("0X")
            if not HEX_WORD.match(token):
                continue
            value = int(token, 16)
            if saw_address:
                if cursor is None:
                    raise ValueError("data appeared before an @address directive")
                words[cursor] = value
                cursor += 1
            else:
                sequential.append(value)

    if saw_address:
        return words
    if not sequential:
        raise ValueError("no 8-digit hexadecimal words were found")

    if explicit_start is not None:
        start_word = explicit_start
    elif len(sequential) >= 832:
        start_word = 0
    elif len(sequential) == 320:
        start_word = 512
    else:
        raise ValueError(
            f"found {len(sequential)} words; pass --start-word when the dump is a custom slice"
        )
    return {start_word + index: value for index, value in enumerate(sequential)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("dump", type=Path, help="ModelSim Data Memory export")
    parser.add_argument(
        "--start-word",
        type=lambda value: int(value, 0),
        help="word index represented by the first line of an address-less dump",
    )
    args = parser.parse_args()

    root = Path(__file__).resolve().parent
    map_path = root / "ready" / "ALL_TESTS_ONE_RUN" / "signature_map.json"
    rows = json.loads(map_path.read_text())
    actual = parse_dump(args.dump, args.start_word)

    passed = 0
    failed = 0
    for row in rows:
        differences = []
        for check in row["checks"]:
            index = check["word_index"]
            wanted = int(check["expected"], 16)
            observed = actual.get(index)
            if observed != wanted:
                observed_text = "MISSING" if observed is None else f"{observed:08x}"
                differences.append(
                    f"{check['field']}@MEM[{index}]={observed_text}, expected {wanted:08x}"
                )

        if differences:
            failed += 1
            print(f"FAIL {row['test']}")
            for difference in differences:
                print(f"     {difference}")
        else:
            passed += 1
            print(f"PASS {row['test']}")

    print(f"\nSummary: {passed} passed, {failed} failed")
    raise SystemExit(1 if failed else 0)


if __name__ == "__main__":
    main()
