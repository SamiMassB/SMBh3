#!/usr/bin/env python3
"""Assemble the suite and verify every declared result with a MIPS reference model."""

import argparse
import importlib.util
import json
from pathlib import Path


MASK32 = 0xFFFFFFFF
INITIAL_DATA = [
    0x12345678,
    0xFFFFFFFF,
    0x80000000,
    0x00000007,
    0x00000022,
    0x7FFFFFFF,
    0x00000004,
    0xAAAA5555,
] + [0] * 120


def signed(value, bits=32):
    value &= (1 << bits) - 1
    sign_bit = 1 << (bits - 1)
    return value - (1 << bits) if value & sign_bit else value


def load_assembler(path):
    spec = importlib.util.spec_from_file_location("course_assembler", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load assembler from {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run_reference(words, initial_data=INITIAL_DATA):
    registers = [0] * 32
    memory = list(initial_data) + [0] * (1024 - len(initial_data))
    pc = 0

    for _ in range(10000):
        if pc & 3 or pc < 0 or pc // 4 >= len(words):
            raise AssertionError(f"invalid instruction address 0x{pc:08x}")

        word = words[pc // 4]
        opcode = word >> 26
        rs = (word >> 21) & 31
        rt = (word >> 16) & 31
        rd = (word >> 11) & 31
        shamt = (word >> 6) & 31
        funct = word & 63
        immediate = word & 0xFFFF
        simmediate = signed(immediate, 16)
        next_pc = (pc + 4) & MASK32

        if opcode == 0:
            if funct in (0x20, 0x21):
                registers[rd] = (registers[rs] + registers[rt]) & MASK32
            elif funct in (0x22, 0x23):
                registers[rd] = (registers[rs] - registers[rt]) & MASK32
            elif funct == 0x24:
                registers[rd] = registers[rs] & registers[rt]
            elif funct == 0x25:
                registers[rd] = registers[rs] | registers[rt]
            elif funct == 0x26:
                registers[rd] = registers[rs] ^ registers[rt]
            elif funct == 0x27:
                registers[rd] = ~(registers[rs] | registers[rt]) & MASK32
            elif funct == 0x2A:
                registers[rd] = int(signed(registers[rs]) < signed(registers[rt]))
            elif funct == 0x2B:
                registers[rd] = int(registers[rs] < registers[rt])
            elif funct == 0x00:
                registers[rd] = (registers[rt] << shamt) & MASK32
            elif funct == 0x02:
                registers[rd] = registers[rt] >> shamt
            elif funct == 0x03:
                registers[rd] = (signed(registers[rt]) >> shamt) & MASK32
            elif funct == 0x04:
                registers[rd] = (registers[rt] << (registers[rs] & 31)) & MASK32
            elif funct == 0x06:
                registers[rd] = registers[rt] >> (registers[rs] & 31)
            elif funct == 0x07:
                registers[rd] = (signed(registers[rt]) >> (registers[rs] & 31)) & MASK32
            elif funct == 0x08:
                next_pc = registers[rs]
            elif funct == 0x09:
                target = registers[rs]
                registers[rd] = next_pc
                next_pc = target
            else:
                raise AssertionError(f"unsupported R funct 0x{funct:02x} at 0x{pc:08x}")
        elif opcode in (0x08, 0x09):
            registers[rt] = (registers[rs] + simmediate) & MASK32
        elif opcode == 0x0A:
            registers[rt] = int(signed(registers[rs]) < simmediate)
        elif opcode == 0x0B:
            registers[rt] = int(registers[rs] < (simmediate & MASK32))
        elif opcode == 0x0C:
            registers[rt] = registers[rs] & immediate
        elif opcode == 0x0D:
            registers[rt] = registers[rs] | immediate
        elif opcode == 0x0E:
            registers[rt] = registers[rs] ^ immediate
        elif opcode == 0x0F:
            registers[rt] = immediate << 16
        elif opcode in (0x23, 0x2B):
            address = (registers[rs] + simmediate) & MASK32
            if address & 3 or address // 4 >= len(memory):
                raise AssertionError(f"invalid data address 0x{address:08x} at 0x{pc:08x}")
            if opcode == 0x23:
                registers[rt] = memory[address // 4]
            else:
                memory[address // 4] = registers[rt]
        elif opcode in (0x04, 0x05):
            equal = registers[rs] == registers[rt]
            if equal == (opcode == 0x04):
                next_pc = (next_pc + (simmediate << 2)) & MASK32
        elif opcode in (0x02, 0x03):
            target = (next_pc & 0xF0000000) | ((word & 0x03FFFFFF) << 2)
            if opcode == 0x03:
                registers[31] = next_pc
            if target == pc:
                registers[0] = 0
                return registers, memory
            next_pc = target
        else:
            raise AssertionError(f"unsupported opcode 0x{opcode:02x} at 0x{pc:08x}")

        registers[0] = 0
        pc = next_pc

    raise AssertionError("program did not reach halt within 10000 instructions")


def verify_expected(name, registers, memory, expected):
    failures = []
    for index, text_value in expected["registers"].items():
        actual = registers[int(index)]
        wanted = int(text_value, 16)
        if actual != wanted:
            failures.append(f"R{index}: got {actual:08x}, expected {wanted:08x}")
    for index, text_value in expected["memory"].items():
        actual = memory[int(index)]
        wanted = int(text_value, 16)
        if actual != wanted:
            failures.append(f"MEM[{index}]: got {actual:08x}, expected {wanted:08x}")
    if failures:
        raise AssertionError(f"{name}: " + "; ".join(failures))


def source_without_halt(path):
    lines = []
    for line in path.read_text().splitlines():
        instruction = line.split("#", 1)[0].strip().lower()
        if instruction == "halt":
            continue
        lines.append(line)
    return lines


def build_single_run(root, sources, expected, assembler):
    row_words = 16
    first_row_word = 512
    sentinel = 0xDEADBEEF
    combined_data = INITIAL_DATA + [0] * (first_row_word - len(INITIAL_DATA))
    combined_data += [sentinel] * (row_words * len(sources))

    combined_lines = [
        "# اجرای یک‌مرحله‌ای تمام تست‌ها؛ این فایل را تغییر ندهید.",
        "# هر تست خروجی خود را در یک ردیف 16 کلمه‌ای از Data Memory می‌نویسد.",
        "",
    ]
    signature_rows = []

    for test_index, source in enumerate(sources):
        name = source.stem
        checks = expected[name]
        register_checks = sorted((int(k), v) for k, v in checks["registers"].items())
        memory_checks = sorted((int(k), v) for k, v in checks["memory"].items())
        if 1 + len(register_checks) + len(memory_checks) > row_words:
            raise AssertionError(f"{name} has too many checks for one signature row")

        combined_lines.extend([f"# ===== {name} =====", ""])
        for memory_index, _ in memory_checks:
            initial_value = INITIAL_DATA[memory_index] if memory_index < len(INITIAL_DATA) else 0
            if initial_value != 0:
                raise AssertionError(f"combined reset for nonzero MEM[{memory_index}] is not implemented")
            combined_lines.append(f"sw $zero, {memory_index * 4}($zero)")
        if memory_checks:
            combined_lines.extend(["nop 4", ""])

        combined_lines.extend(source_without_halt(source))
        combined_lines.extend(["nop 4", ""])

        row_word = first_row_word + test_index * row_words
        row = {
            "test": name,
            "row_word": row_word,
            "byte_address": row_word * 4,
            "checks": [
                {
                    "slot": 0,
                    "word_index": row_word,
                    "byte_address": row_word * 4,
                    "field": "COMPLETE",
                    "expected": "00000000",
                }
            ],
        }
        slot = 1
        for register_index, value in register_checks:
            signature_word = row_word + slot
            combined_lines.append(f"sw ${register_index}, {signature_word * 4}($zero)")
            row["checks"].append({
                "slot": slot,
                "word_index": signature_word,
                "byte_address": signature_word * 4,
                "field": f"R{register_index}",
                "expected": value,
            })
            slot += 1

        for memory_index, value in memory_checks:
            signature_word = row_word + slot
            combined_lines.extend([
                f"lw $k0, {memory_index * 4}($zero)",
                "nop 4",
                f"sw $k0, {signature_word * 4}($zero)",
            ])
            row["checks"].append({
                "slot": slot,
                "word_index": signature_word,
                "byte_address": signature_word * 4,
                "field": f"MEM[{memory_index}]",
                "expected": value,
            })
            slot += 1

        combined_lines.extend([
            "nop 4",
            f"sw $zero, {row_word * 4}($zero)",
            "nop 4",
            "",
        ])
        signature_rows.append(row)

    combined_lines.append("halt")
    combined_source = "\n".join(combined_lines) + "\n"
    combined_words, labels = assembler.assemble(combined_source)
    if len(combined_words) > 1024:
        raise AssertionError(f"single-run program has {len(combined_words)} instructions; limit is 1024")

    dynamic_expected = {
        "17_jump_and_jal": {
            "R18": labels["jal_target"] - 4,
            "R31": labels["jal_target"] - 4,
        },
        "18_jr_and_jalr": {
            "R8": labels["jr_target"],
            "R9": labels["jalr_target"],
            "R18": labels["jalr_target"] - 4,
            "R19": labels["jalr_target"] - 4,
        },
    }
    for row in signature_rows:
        replacements = dynamic_expected.get(row["test"], {})
        for check in row["checks"]:
            if check["field"] in replacements:
                check["expected"] = f"{replacements[check['field']] & MASK32:08x}"

    _, final_memory = run_reference(combined_words, combined_data)
    for row in signature_rows:
        for check in row["checks"]:
            actual = final_memory[check["word_index"]]
            wanted = int(check["expected"], 16)
            if actual != wanted:
                raise AssertionError(
                    f"single-run {row['test']} {check['field']}: "
                    f"got {actual:08x}, expected {wanted:08x}"
                )

    output_dir = root / "ready" / "ALL_TESTS_ONE_RUN"
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "source.s").write_text(combined_source)
    (output_dir / "program.mem").write_text(assembler.to_mem(combined_words))
    (output_dir / "data50.mem").write_text("".join(f"{word:08x}\n" for word in combined_data))
    (output_dir / "signature_map.json").write_text(json.dumps(signature_rows, indent=2) + "\n")
    signature_grid = final_memory[first_row_word:first_row_word + row_words * len(sources)]
    (output_dir / "expected_signature_grid.mem").write_text(
        "".join(f"{word:08x}\n" for word in signature_grid)
    )
    row_lines = []
    for row_index, row in enumerate(signature_rows):
        start = row_index * row_words
        values = " ".join(f"{word:08x}" for word in signature_grid[start:start + row_words])
        row_lines.append(f"{row['test']}: {values}")
    (output_dir / "expected_grid_rows.txt").write_text("\n".join(row_lines) + "\n")

    csv_lines = ["test,row_word,byte_address,field,expected"]
    for row in signature_rows:
        for check in row["checks"]:
            csv_lines.append(
                f"{row['test']},{check['word_index']},0x{check['byte_address']:03x},"
                f"{check['field']},{check['expected']}"
            )
    (output_dir / "expected_signatures.csv").write_text("\n".join(csv_lines) + "\n")
    print(f"PASS ALL_TESTS_ONE_RUN       {len(combined_words):3d} instructions")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--assembler", required=True, type=Path, help="path to the supplied Assembler.py")
    args = parser.parse_args()

    root = Path(__file__).resolve().parent
    assembler = load_assembler(args.assembler.resolve())
    expected = json.loads((root / "expected.json").read_text())
    sources = sorted((root / "src").glob("*.s"))
    source_names = {path.stem for path in sources}
    if source_names != set(expected):
        raise AssertionError("source files and expected.json entries do not match")

    data_text = "".join(f"{word:08x}\n" for word in INITIAL_DATA)
    for source in sources:
        words, _ = assembler.assemble(source.read_text())
        if len(words) > 1024:
            raise AssertionError(f"{source.name} exceeds the 1024-instruction limit")
        registers, memory = run_reference(words)
        verify_expected(source.stem, registers, memory, expected[source.stem])

        output_dir = root / "ready" / source.stem
        output_dir.mkdir(parents=True, exist_ok=True)
        (output_dir / "program.mem").write_text(assembler.to_mem(words))
        (output_dir / "data50.mem").write_text(data_text)
        (output_dir / "source.s").write_text(source.read_text())
        print(f"PASS {source.stem:24s} {len(words):3d} instructions")

    build_single_run(root, sources, expected, assembler)
    print(f"\nVerified and built {len(sources)} tests plus the single-run image.")


if __name__ == "__main__":
    main()
