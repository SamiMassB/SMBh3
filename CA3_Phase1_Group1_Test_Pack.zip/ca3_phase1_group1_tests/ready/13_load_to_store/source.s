# Hazard از LW به داده و آدرس SW
lw $t0, 0($zero)
sw $t0, 256($zero)

addi $t1, $zero, 55
nop 4
lw $t2, 24($zero)
sw $t1, 256($t2)
nop 4
halt
