# Forwarding برای هر دو ورودی ALU
addi $t0, $zero, 5
add  $t1, $t0, $t0
addi $t2, $zero, 3
add  $t3, $t1, $t2
addi $t4, $zero, 4
sub  $t5, $t4, $t3
xor  $t6, $t5, $t0
nop 4
halt
