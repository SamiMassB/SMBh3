# Forwarding مستقل داده و آدرس SW
addi $t0, $zero, 77
sw $t0, 256($zero)

addi $t1, $zero, 99
nop 4
addi $t2, $zero, 260
sw $t1, 0($t2)

addi $t3, $zero, 264
addi $t4, $zero, 88
sw $t4, 0($t3)
nop 4
halt
