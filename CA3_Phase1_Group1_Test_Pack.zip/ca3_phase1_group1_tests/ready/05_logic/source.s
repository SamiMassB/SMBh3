# همه عملگرهای منطقی رجیستر به رجیستر
lui $t0, 0xaaaa
nop 4
ori $t0, $t0, 0x5555
lui $t1, 0x0f0f
nop 4
ori $t1, $t1, 0xf0f0
nop 4
and $t2, $t0, $t1
or  $t3, $t0, $t1
xor $t4, $t0, $t1
nor $t5, $t0, $t1
nop 4
halt
