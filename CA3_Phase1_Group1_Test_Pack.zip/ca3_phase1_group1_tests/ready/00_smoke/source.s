# مسیر پایه بدون وابستگی پایپ‌لاین
addi $t0, $zero, 5
nop 4
addi $t1, $zero, 7
nop 4
add $t2, $t0, $t1
nop 4
sw $t2, 256($zero)
nop 4
halt
