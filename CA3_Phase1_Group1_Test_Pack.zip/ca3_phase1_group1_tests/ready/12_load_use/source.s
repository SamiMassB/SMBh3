# سه Load-use بلافاصله پس از LW
lw   $t0, 0($zero)
add  $t1, $t0, $t0
lw   $t2, 12($zero)
addi $t3, $t2, 5
lw   $t4, 4($zero)
andi $t5, $t4, 0x00ff
nop 4
halt
