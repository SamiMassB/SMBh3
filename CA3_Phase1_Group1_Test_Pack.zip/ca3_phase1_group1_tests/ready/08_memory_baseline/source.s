# LW/SW با آدرس پایه، offset مثبت و offset منفی، بدون Hazard
lw $t0, 0($zero)
nop 4
lw $t1, 4($zero)
nop 4
addi $s0, $zero, 8
nop 4
lw $t2, 4($s0)
nop 4
lw $t3, -8($s0)
nop 4
sw $t0, 256($zero)
nop 4
sw $t1, 260($zero)
nop 4
sw $t2, 264($zero)
nop 4
sw $t3, 268($zero)
nop 4
halt
