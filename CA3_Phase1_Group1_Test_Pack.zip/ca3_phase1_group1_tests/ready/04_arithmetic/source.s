# جمع، تفریق و wrap-around سرریز
lui $t0, 0x7fff
nop 4
ori $t0, $t0, 0xffff
addi $t1, $zero, 1
addi $t6, $zero, -7
addi $t7, $zero, 3
nop 4
add  $t2, $t0, $t1
addu $t3, $t0, $t1
sub  $t4, $t0, $t1
subu $t5, $t0, $t1
add  $s0, $t6, $t7
sub  $s1, $t6, $t7
nop 4
halt
