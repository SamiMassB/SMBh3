# اجرای یک‌مرحله‌ای تمام تست‌ها؛ این فایل را تغییر ندهید.
# هر تست خروجی خود را در یک ردیف 16 کلمه‌ای از Data Memory می‌نویسد.

# ===== 00_smoke =====

sw $zero, 256($zero)
nop 4

# مسیر پایه بدون وابستگی پایپ‌لاین
addi $t0, $zero, 5
nop 4
addi $t1, $zero, 7
nop 4
add $t2, $t0, $t1
nop 4
sw $t2, 256($zero)
nop 4
nop 4

sw $8, 2052($zero)
sw $9, 2056($zero)
sw $10, 2060($zero)
lw $k0, 256($zero)
nop 4
sw $k0, 2064($zero)
nop 4
sw $zero, 2048($zero)
nop 4

# ===== 01_zero_register =====

# ثبات رجیستر صفر و انتخاب مقصد
addi $zero, $zero, 99
nop 4
addi $t0, $zero, 11
nop 4
add $zero, $t0, $t0
nop 4
add $t1, $t0, $zero
nop 4
nop 4

sw $0, 2116($zero)
sw $8, 2120($zero)
sw $9, 2124($zero)
nop 4
sw $zero, 2112($zero)
nop 4

# ===== 02_immediate_extension =====

# sign-extension و zero-extension و LUI
addi  $t0, $zero, -1
nop 4
addiu $t1, $zero, -32768
nop 4
andi  $t2, $t0, 0x8001
ori   $t3, $zero, 0x8001
xori  $t4, $t0, 0xffff
lui   $t5, 0x8001
nop 4
nop 4

sw $8, 2180($zero)
sw $9, 2184($zero)
sw $10, 2188($zero)
sw $11, 2192($zero)
sw $12, 2196($zero)
sw $13, 2200($zero)
nop 4
sw $zero, 2176($zero)
nop 4

# ===== 03_comparisons =====

# مقایسه‌های علامت‌دار و بدون علامت
addi $t0, $zero, -1
addi $t1, $zero, 1
nop 4
slti  $t2, $t0, 0
slti  $t3, $t1, -1
sltiu $t4, $t0, 1
sltiu $t5, $t1, -1
slt   $s0, $t0, $t1
sltu  $s1, $t0, $t1
nop 4
nop 4

sw $8, 2244($zero)
sw $9, 2248($zero)
sw $10, 2252($zero)
sw $11, 2256($zero)
sw $12, 2260($zero)
sw $13, 2264($zero)
sw $16, 2268($zero)
sw $17, 2272($zero)
nop 4
sw $zero, 2240($zero)
nop 4

# ===== 04_arithmetic =====

# جمع، تفریق و wrap-around سرریز
lui $t0, 0x7fff
nop 4
ori $t0, $t0, 0xffff
addi $t1, $zero, 1
addi $t6, $zero, -7
addi $t7, $zero, 3
nop 4
add  $t2, $t0, $t1
addu $t3, $t0, $t1
sub  $t4, $t0, $t1
subu $t5, $t0, $t1
add  $s0, $t6, $t7
sub  $s1, $t6, $t7
nop 4
nop 4

sw $8, 2308($zero)
sw $9, 2312($zero)
sw $10, 2316($zero)
sw $11, 2320($zero)
sw $12, 2324($zero)
sw $13, 2328($zero)
sw $14, 2332($zero)
sw $15, 2336($zero)
sw $16, 2340($zero)
sw $17, 2344($zero)
nop 4
sw $zero, 2304($zero)
nop 4

# ===== 05_logic =====

# همه عملگرهای منطقی رجیستر به رجیستر
lui $t0, 0xaaaa
nop 4
ori $t0, $t0, 0x5555
lui $t1, 0x0f0f
nop 4
ori $t1, $t1, 0xf0f0
nop 4
and $t2, $t0, $t1
or  $t3, $t0, $t1
xor $t4, $t0, $t1
nor $t5, $t0, $t1
nop 4
nop 4

sw $8, 2372($zero)
sw $9, 2376($zero)
sw $10, 2380($zero)
sw $11, 2384($zero)
sw $12, 2388($zero)
sw $13, 2392($zero)
nop 4
sw $zero, 2368($zero)
nop 4

# ===== 06_fixed_shifts =====

# شیفت‌های ثابت، شامل مقدار منفی و shamt مرزی
lui $t0, 0x8000
nop 4
ori $t0, $t0, 1
nop 4
sll $t1, $t0, 1
srl $t2, $t0, 1
sra $t3, $t0, 1
sll $t4, $t0, 31
srl $t5, $t0, 31
sra $t6, $t0, 31
sll $t7, $t0, 0
nop 4
nop 4

sw $8, 2436($zero)
sw $9, 2440($zero)
sw $10, 2444($zero)
sw $11, 2448($zero)
sw $12, 2452($zero)
sw $13, 2456($zero)
sw $14, 2460($zero)
sw $15, 2464($zero)
nop 4
sw $zero, 2432($zero)
nop 4

# ===== 07_variable_shifts =====

# شیفت متغیر باید فقط پنج بیت پایین مقدار شیفت را مصرف کند
lui $t0, 0x8000
nop 4
ori $t0, $t0, 1
addi $t1, $zero, 33
nop 4
sllv $t2, $t0, $t1
srlv $t3, $t0, $t1
srav $t4, $t0, $t1
nop 4
nop 4

sw $8, 2500($zero)
sw $9, 2504($zero)
sw $10, 2508($zero)
sw $11, 2512($zero)
sw $12, 2516($zero)
nop 4
sw $zero, 2496($zero)
nop 4

# ===== 08_memory_baseline =====

sw $zero, 256($zero)
sw $zero, 260($zero)
sw $zero, 264($zero)
sw $zero, 268($zero)
nop 4

# LW/SW با آدرس پایه، offset مثبت و offset منفی، بدون Hazard
lw $t0, 0($zero)
nop 4
lw $t1, 4($zero)
nop 4
addi $s0, $zero, 8
nop 4
lw $t2, 4($s0)
nop 4
lw $t3, -8($s0)
nop 4
sw $t0, 256($zero)
nop 4
sw $t1, 260($zero)
nop 4
sw $t2, 264($zero)
nop 4
sw $t3, 268($zero)
nop 4
nop 4

sw $8, 2564($zero)
sw $9, 2568($zero)
sw $10, 2572($zero)
sw $11, 2576($zero)
sw $16, 2580($zero)
lw $k0, 256($zero)
nop 4
sw $k0, 2584($zero)
lw $k0, 260($zero)
nop 4
sw $k0, 2588($zero)
lw $k0, 264($zero)
nop 4
sw $k0, 2592($zero)
lw $k0, 268($zero)
nop 4
sw $k0, 2596($zero)
nop 4
sw $zero, 2560($zero)
nop 4

# ===== 09_alu_forwarding =====

# Forwarding برای هر دو ورودی ALU
addi $t0, $zero, 5
add  $t1, $t0, $t0
addi $t2, $zero, 3
add  $t3, $t1, $t2
addi $t4, $zero, 4
sub  $t5, $t4, $t3
xor  $t6, $t5, $t0
nop 4
nop 4

sw $8, 2628($zero)
sw $9, 2632($zero)
sw $10, 2636($zero)
sw $11, 2640($zero)
sw $12, 2644($zero)
sw $13, 2648($zero)
sw $14, 2652($zero)
nop 4
sw $zero, 2624($zero)
nop 4

# ===== 10_forwarding_priority =====

# جدیدترین مقدار رجیستر باید اولویت داشته باشد
addi $t0, $zero, 1
addi $t0, $t0, 2
addi $t0, $t0, 4
add  $t1, $t0, $t0
addi $t2, $zero, 10
addi $t3, $t2, 1
add  $t4, $t2, $t3
nop 4
nop 4

sw $8, 2692($zero)
sw $9, 2696($zero)
sw $10, 2700($zero)
sw $11, 2704($zero)
sw $12, 2708($zero)
nop 4
sw $zero, 2688($zero)
nop 4

# ===== 11_store_forwarding =====

sw $zero, 256($zero)
sw $zero, 260($zero)
sw $zero, 264($zero)
nop 4

# Forwarding مستقل داده و آدرس SW
addi $t0, $zero, 77
sw $t0, 256($zero)

addi $t1, $zero, 99
nop 4
addi $t2, $zero, 260
sw $t1, 0($t2)

addi $t3, $zero, 264
addi $t4, $zero, 88
sw $t4, 0($t3)
nop 4
nop 4

sw $8, 2756($zero)
sw $9, 2760($zero)
sw $10, 2764($zero)
sw $11, 2768($zero)
sw $12, 2772($zero)
lw $k0, 256($zero)
nop 4
sw $k0, 2776($zero)
lw $k0, 260($zero)
nop 4
sw $k0, 2780($zero)
lw $k0, 264($zero)
nop 4
sw $k0, 2784($zero)
nop 4
sw $zero, 2752($zero)
nop 4

# ===== 12_load_use =====

# سه Load-use بلافاصله پس از LW
lw   $t0, 0($zero)
add  $t1, $t0, $t0
lw   $t2, 12($zero)
addi $t3, $t2, 5
lw   $t4, 4($zero)
andi $t5, $t4, 0x00ff
nop 4
nop 4

sw $8, 2820($zero)
sw $9, 2824($zero)
sw $10, 2828($zero)
sw $11, 2832($zero)
sw $12, 2836($zero)
sw $13, 2840($zero)
nop 4
sw $zero, 2816($zero)
nop 4

# ===== 13_load_to_store =====

sw $zero, 256($zero)
sw $zero, 260($zero)
nop 4

# Hazard از LW به داده و آدرس SW
lw $t0, 0($zero)
sw $t0, 256($zero)

addi $t1, $zero, 55
nop 4
lw $t2, 24($zero)
sw $t1, 256($t2)
nop 4
nop 4

sw $8, 2884($zero)
sw $9, 2888($zero)
sw $10, 2892($zero)
lw $k0, 256($zero)
nop 4
sw $k0, 2896($zero)
lw $k0, 260($zero)
nop 4
sw $k0, 2900($zero)
nop 4
sw $zero, 2880($zero)
nop 4

# ===== 14_branch_modes =====

# BEQ/BNE در حالت taken و not-taken و Flush مسیر اشتباه
addi $t0, $zero, 5
addi $t1, $zero, 5
addi $t2, $zero, 6
nop 4

addi $s0, $zero, 1
beq $t0, $t1, beq_taken_ok
addi $s0, $zero, -1
beq_taken_ok:
nop 2

addi $s1, $zero, 2
beq $t0, $t2, beq_not_taken_ok
addi $s1, $zero, 3
beq_not_taken_ok:
nop 2

addi $s2, $zero, 4
bne $t0, $t2, bne_taken_ok
addi $s2, $zero, -1
bne_taken_ok:
nop 2

addi $s3, $zero, 8
bne $t0, $t1, bne_not_taken_wrong
addi $s3, $zero, 9
j branch_done
bne_not_taken_wrong:
addi $s3, $zero, -1
branch_done:
nop 4
nop 4

sw $16, 2948($zero)
sw $17, 2952($zero)
sw $18, 2956($zero)
sw $19, 2960($zero)
nop 4
sw $zero, 2944($zero)
nop 4

# ===== 15_branch_hazards =====

# Forwarding و Stall روی ورودی مقایسه‌کننده Branch
addi $s0, $zero, 1
nop 4
addi $t0, $zero, 5
bne $t0, $zero, alu_branch_done
addi $s0, $zero, -1
alu_branch_done:
nop 2

addi $s1, $zero, 2
addi $t1, $zero, 7
addi $t2, $zero, 7
beq $t1, $t2, two_source_ok
addi $s1, $zero, -1
two_source_ok:
nop 2

addi $s2, $zero, 4
addi $t3, $zero, 7
nop 4
lw $t4, 12($zero)
beq $t4, $t3, load_branch_ok
addi $s2, $zero, -1
load_branch_ok:
nop 4
nop 4

sw $8, 3012($zero)
sw $9, 3016($zero)
sw $10, 3020($zero)
sw $11, 3024($zero)
sw $12, 3028($zero)
sw $16, 3032($zero)
sw $17, 3036($zero)
sw $18, 3040($zero)
nop 4
sw $zero, 3008($zero)
nop 4

# ===== 16_backward_branch =====

# offset منفی Branch و حلقه سه‌مرحله‌ای
addi $t0, $zero, 0
addi $t1, $zero, 3
nop 4
loop:
addi $t0, $t0, 1
nop 4
bne $t0, $t1, loop
nop 4
nop 4

sw $8, 3076($zero)
sw $9, 3080($zero)
nop 4
sw $zero, 3072($zero)
nop 4

# ===== 17_jump_and_jal =====

# J/JAL، Flush و مقدار لینک PC+4
addi $s0, $zero, 1
nop 4
j j_target
addi $s0, $zero, -1
j_target:
addi $s1, $zero, 2
nop 4
jal jal_target
addi $s1, $zero, -1
jal_target:
nop 4
add $s2, $ra, $zero
nop 4
nop 4

sw $16, 3140($zero)
sw $17, 3144($zero)
sw $18, 3148($zero)
sw $31, 3152($zero)
nop 4
sw $zero, 3136($zero)
nop 4

# ===== 18_jr_and_jalr =====

# JR/JALR، Flush، مقصد رجیستری و مقدار لینک PC+4
addi $s0, $zero, 1
addi $t0, $zero, jr_target
nop 4
jr $t0
addi $s0, $zero, -1
jr_target:
addi $s1, $zero, 2
nop 4
addi $t1, $zero, jalr_target
nop 4
jalr $s2, $t1
addi $s1, $zero, -1
jalr_target:
nop 4
add $s3, $s2, $zero
nop 4
nop 4

sw $8, 3204($zero)
sw $9, 3208($zero)
sw $16, 3212($zero)
sw $17, 3216($zero)
sw $18, 3220($zero)
sw $19, 3224($zero)
nop 4
sw $zero, 3200($zero)
nop 4

# ===== 19_wrong_path_store =====

sw $zero, 256($zero)
sw $zero, 260($zero)
nop 4

# دستور Store در مسیر اشتباه نباید اثری بگذارد
addi $t0, $zero, 99
addi $t1, $zero, 1
nop 4
beq $t1, $t1, branch_target
sw $t0, 256($zero)
branch_target:
nop 4
j jump_target
sw $t0, 260($zero)
jump_target:
nop 4
nop 4

sw $8, 3268($zero)
sw $9, 3272($zero)
lw $k0, 256($zero)
nop 4
sw $k0, 3276($zero)
lw $k0, 260($zero)
nop 4
sw $k0, 3280($zero)
nop 4
sw $zero, 3264($zero)
nop 4

halt
