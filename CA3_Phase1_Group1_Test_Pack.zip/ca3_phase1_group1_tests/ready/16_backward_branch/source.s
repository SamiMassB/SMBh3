# offset منفی Branch و حلقه سه‌مرحله‌ای
addi $t0, $zero, 0
addi $t1, $zero, 3
nop 4
loop:
addi $t0, $t0, 1
nop 4
bne $t0, $t1, loop
nop 4
halt
