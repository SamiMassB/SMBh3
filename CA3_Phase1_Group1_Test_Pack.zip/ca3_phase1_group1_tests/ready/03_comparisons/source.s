# مقایسه‌های علامت‌دار و بدون علامت
addi $t0, $zero, -1
addi $t1, $zero, 1
nop 4
slti  $t2, $t0, 0
slti  $t3, $t1, -1
sltiu $t4, $t0, 1
sltiu $t5, $t1, -1
slt   $s0, $t0, $t1
sltu  $s1, $t0, $t1
nop 4
halt
