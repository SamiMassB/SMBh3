# شیفت‌های ثابت، شامل مقدار منفی و shamt مرزی
lui $t0, 0x8000
nop 4
ori $t0, $t0, 1
nop 4
sll $t1, $t0, 1
srl $t2, $t0, 1
sra $t3, $t0, 1
sll $t4, $t0, 31
srl $t5, $t0, 31
sra $t6, $t0, 31
sll $t7, $t0, 0
nop 4
halt
