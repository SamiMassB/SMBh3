# J/JAL، Flush و مقدار لینک PC+4
addi $s0, $zero, 1
nop 4
j j_target
addi $s0, $zero, -1
j_target:
addi $s1, $zero, 2
nop 4
jal jal_target
addi $s1, $zero, -1
jal_target:
nop 4
add $s2, $ra, $zero
nop 4
halt
