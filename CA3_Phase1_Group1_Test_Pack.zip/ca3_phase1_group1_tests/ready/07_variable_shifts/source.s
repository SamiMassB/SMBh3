# شیفت متغیر باید فقط پنج بیت پایین مقدار شیفت را مصرف کند
lui $t0, 0x8000
nop 4
ori $t0, $t0, 1
addi $t1, $zero, 33
nop 4
sllv $t2, $t0, $t1
srlv $t3, $t0, $t1
srav $t4, $t0, $t1
nop 4
halt
