# ثبات رجیستر صفر و انتخاب مقصد
addi $zero, $zero, 99
nop 4
addi $t0, $zero, 11
nop 4
add $zero, $t0, $t0
nop 4
add $t1, $t0, $zero
nop 4
halt
