# جدیدترین مقدار رجیستر باید اولویت داشته باشد
addi $t0, $zero, 1
addi $t0, $t0, 2
addi $t0, $t0, 4
add  $t1, $t0, $t0
addi $t2, $zero, 10
addi $t3, $t2, 1
add  $t4, $t2, $t3
nop 4
halt
