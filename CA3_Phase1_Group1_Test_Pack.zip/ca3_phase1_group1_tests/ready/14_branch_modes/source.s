# BEQ/BNE در حالت taken و not-taken و Flush مسیر اشتباه
addi $t0, $zero, 5
addi $t1, $zero, 5
addi $t2, $zero, 6
nop 4

addi $s0, $zero, 1
beq $t0, $t1, beq_taken_ok
addi $s0, $zero, -1
beq_taken_ok:
nop 2

addi $s1, $zero, 2
beq $t0, $t2, beq_not_taken_ok
addi $s1, $zero, 3
beq_not_taken_ok:
nop 2

addi $s2, $zero, 4
bne $t0, $t2, bne_taken_ok
addi $s2, $zero, -1
bne_taken_ok:
nop 2

addi $s3, $zero, 8
bne $t0, $t1, bne_not_taken_wrong
addi $s3, $zero, 9
j branch_done
bne_not_taken_wrong:
addi $s3, $zero, -1
branch_done:
nop 4
halt
