# Forwarding و Stall روی ورودی مقایسه‌کننده Branch
addi $s0, $zero, 1
nop 4
addi $t0, $zero, 5
bne $t0, $zero, alu_branch_done
addi $s0, $zero, -1
alu_branch_done:
nop 2

addi $s1, $zero, 2
addi $t1, $zero, 7
addi $t2, $zero, 7
beq $t1, $t2, two_source_ok
addi $s1, $zero, -1
two_source_ok:
nop 2

addi $s2, $zero, 4
addi $t3, $zero, 7
nop 4
lw $t4, 12($zero)
beq $t4, $t3, load_branch_ok
addi $s2, $zero, -1
load_branch_ok:
nop 4
halt
