# sign-extension و zero-extension و LUI
addi  $t0, $zero, -1
nop 4
addiu $t1, $zero, -32768
nop 4
andi  $t2, $t0, 0x8001
ori   $t3, $zero, 0x8001
xori  $t4, $t0, 0xffff
lui   $t5, 0x8001
nop 4
halt
