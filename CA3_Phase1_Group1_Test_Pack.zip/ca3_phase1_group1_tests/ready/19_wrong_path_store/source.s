# دستور Store در مسیر اشتباه نباید اثری بگذارد
addi $t0, $zero, 99
addi $t1, $zero, 1
nop 4
beq $t1, $t1, branch_target
sw $t0, 256($zero)
branch_target:
nop 4
j jump_target
sw $t0, 260($zero)
jump_target:
nop 4
halt
