# JR/JALR، Flush، مقصد رجیستری و مقدار لینک PC+4
addi $s0, $zero, 1
addi $t0, $zero, jr_target
nop 4
jr $t0
addi $s0, $zero, -1
jr_target:
addi $s1, $zero, 2
nop 4
addi $t1, $zero, jalr_target
nop 4
jalr $s2, $t1
addi $s1, $zero, -1
jalr_target:
nop 4
add $s3, $s2, $zero
nop 4
halt
