# Before running this file, define PROCESSOR_DIR and TEST_DIR in ModelSim.
# PROCESSOR_DIR must contain the protected .vp files and TopPipeline_tb.v.
# TEST_DIR must be one directory under ready/ and contain program.mem/data50.mem.

if {![info exists PROCESSOR_DIR]} {
    error "PROCESSOR_DIR is not set"
}
if {![info exists TEST_DIR]} {
    error "TEST_DIR is not set"
}

set PROCESSOR_DIR [file normalize $PROCESSOR_DIR]
set TEST_DIR [file normalize $TEST_DIR]
set testbench_file [file join $PROCESSOR_DIR TopPipeline_tb.v]
set protected_files [glob -nocomplain -directory $PROCESSOR_DIR *.vp]

if {![file exists $testbench_file]} {
    error "TopPipeline_tb.v was not found in $PROCESSOR_DIR"
}
if {[llength $protected_files] == 0} {
    error "No protected .vp files were found in $PROCESSOR_DIR"
}
if {![file exists [file join $TEST_DIR program.mem]]} {
    error "program.mem was not found in $TEST_DIR"
}
if {![file exists [file join $TEST_DIR data50.mem]]} {
    error "data50.mem was not found in $TEST_DIR"
}

cd $TEST_DIR
if {[file exists work]} {
    vdel -lib work -all
}
vlib work
vmap work work
eval vlog $protected_files [list $testbench_file]
vsim -voptargs=+acc work.TopPipeline_tb
run -all

puts "Simulation finished. Inspect Register File, Data Memory, and Instruction Memory in Memory List."
